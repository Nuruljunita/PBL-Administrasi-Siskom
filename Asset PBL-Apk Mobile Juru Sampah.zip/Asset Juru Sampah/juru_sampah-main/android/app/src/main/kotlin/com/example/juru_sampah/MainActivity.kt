package com.example.juru_sampah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
